# Flutter Tools

Developer tools for building Flutter applications.

Be sure to follow the instructions on
[CONTRIBUTING.md](../../CONTRIBUTING.md) to setup.

To run the tests, ensure that no devices are connected,
then navigate to `flutter_tools` and execute:

```shell
../../bin/cache/dart-sdk/bin/pub run test
```
