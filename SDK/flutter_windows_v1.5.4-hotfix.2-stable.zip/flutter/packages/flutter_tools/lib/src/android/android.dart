// Copyright 2016 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

const int minApiLevel = 16;
const String minVersionName = 'Jelly Bean';
const String minVersionText = '4.1.x';
